from django.apps import AppConfig


class MerchstoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'merchstore'
